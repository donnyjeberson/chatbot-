// ============================================================
// pages/Chat.jsx - Main Chat Interface
// ============================================================
import { useState, useEffect, useRef, useCallback } from 'react';
import Sidebar from '../components/Sidebar';
import MessageBubble, { TypingIndicator } from '../components/MessageBubble';
import ChatInput from '../components/ChatInput';
import api from '../api/axios';

export default function Chat() {
  const [activeChatId, setActiveChatId] = useState(null);
  const [messages, setMessages]         = useState([]);
  const [input, setInput]               = useState('');
  const [loading, setLoading]           = useState(false);
  const [chatTitle, setChatTitle]       = useState('');
  const [sidebarOpen, setSidebarOpen]   = useState(true);

  const bottomRef = useRef(null);

  // Auto-scroll to bottom whenever messages update
  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages, loading]);

  // Load messages for an existing chat
  const loadChat = useCallback(async (id) => {
    setActiveChatId(id);
    setMessages([]);
    try {
      const { data } = await api.get(`/chat/${id}`);
      setMessages(data.messages);
      setChatTitle(data.chat.title);
    } catch (err) {
      console.error('Failed to load chat:', err.message);
    }
  }, []);

  // Start a new chat
  const handleNewChat = useCallback(() => {
    setActiveChatId(null);
    setMessages([]);
    setChatTitle('');
    setInput('');
  }, []);

  // Send message to backend and display AI response
  const handleSend = async () => {
    const text = input.trim();
    if (!text || loading) return;

    setInput('');
    setLoading(true);

    // Optimistically add user message to UI
    setMessages((prev) => [...prev, { role: 'user', content: text, _id: Date.now() }]);

    try {
      const { data } = await api.post('/chat/send', {
        chatId:  activeChatId,
        content: text,
      });

      // Set chat ID if this was a new chat
      if (!activeChatId) {
        setActiveChatId(data.chat._id);
        setChatTitle(data.chat.title);
      }

      // Add AI response
      setMessages((prev) => [...prev, data.aiMessage]);
    } catch (err) {
      const errMsg = err.response?.data?.message || 'Something went wrong. Please try again.';
      setMessages((prev) => [
        ...prev,
        { role: 'assistant', content: `⚠️ Error: ${errMsg}`, _id: Date.now() },
      ]);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="flex h-screen bg-gray-950 overflow-hidden">

      {/* ── Sidebar ── */}
      {sidebarOpen && (
        <Sidebar
          activeChatId={activeChatId}
          onSelectChat={loadChat}
          onNewChat={handleNewChat}
        />
      )}

      {/* ── Main Chat Area ── */}
      <div className="flex-1 flex flex-col min-w-0">

        {/* ── Top Header ── */}
        <div className="flex items-center gap-3 px-4 py-3 bg-gray-900
                        border-b border-gray-800 flex-shrink-0">
          {/* Toggle sidebar */}
          <button
            onClick={() => setSidebarOpen((v) => !v)}
            className="text-gray-400 hover:text-white transition-colors
                       w-8 h-8 flex items-center justify-center rounded-lg
                       hover:bg-gray-800"
            title="Toggle sidebar"
          >
            ☰
          </button>

          <div className="flex-1 min-w-0">
            <h2 className="text-white font-semibold text-sm truncate">
              {chatTitle || (activeChatId ? 'Chat' : 'New Conversation')}
            </h2>
            <p className="text-gray-500 text-xs">
              {activeChatId ? `${messages.length} messages` : 'Start typing below'}
            </p>
          </div>

          {/* Status indicator */}
          <div className="flex items-center gap-1.5">
            <span className="w-2 h-2 rounded-full bg-green-500 animate-pulse" />
            <span className="text-gray-500 text-xs">AI Online</span>
          </div>
        </div>

        {/* ── Messages Area ── */}
        <div className="flex-1 overflow-y-auto p-4 md:p-6">
          <div className="max-w-3xl mx-auto">

            {/* Welcome Screen */}
            {messages.length === 0 && !loading && (
              <div className="flex flex-col items-center justify-center
                              min-h-[60vh] text-center">
                <div className="w-20 h-20 rounded-3xl bg-indigo-600/20 border
                                border-indigo-600/30 flex items-center justify-center
                                text-4xl mb-6">
                  🤖
                </div>
                <h2 className="text-2xl font-bold text-white mb-2">
                  How can I help you today?
                </h2>
                <p className="text-gray-500 text-sm max-w-md">
                  I'm your AI assistant. Ask me anything — from coding help and
                  writing to analysis and creative ideas.
                </p>

                {/* Suggestion chips */}
                <div className="grid grid-cols-2 gap-2 mt-8 w-full max-w-md">
                  {[
                    '✍️ Help me write an email',
                    '💻 Explain a coding concept',
                    '🧠 Brainstorm ideas',
                    '📊 Analyze some data',
                  ].map((suggestion) => (
                    <button
                      key={suggestion}
                      onClick={() => setInput(suggestion.slice(3))}
                      className="text-left p-3 bg-gray-800 hover:bg-gray-700
                                 text-gray-300 hover:text-white rounded-xl
                                 text-xs transition-colors border border-gray-700
                                 hover:border-indigo-600"
                    >
                      {suggestion}
                    </button>
                  ))}
                </div>
              </div>
            )}

            {/* Message Bubbles */}
            {messages.map((msg) => (
              <MessageBubble
                key={msg._id || `${msg.role}-${msg.content.slice(0, 10)}`}
                role={msg.role}
                content={msg.content}
              />
            ))}

            {/* Typing Indicator */}
            {loading && <TypingIndicator />}

            {/* Scroll anchor */}
            <div ref={bottomRef} />
          </div>
        </div>

        {/* ── Input Bar ── */}
        <ChatInput
          value={input}
          onChange={setInput}
          onSend={handleSend}
          loading={loading}
        />
      </div>
    </div>
  );
}

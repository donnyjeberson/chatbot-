// ============================================================
// components/Sidebar.jsx - Chat Sessions Sidebar
// ============================================================
import { useEffect, useState, useCallback } from 'react';
import api from '../api/axios';
import { useAuth } from '../context/AuthContext';

export default function Sidebar({ activeChatId, onSelectChat, onNewChat }) {
  const [chats, setChats]       = useState([]);
  const [loading, setLoading]   = useState(false);
  const { user, logout }        = useAuth();

  const fetchChats = useCallback(async () => {
    setLoading(true);
    try {
      const { data } = await api.get('/chat/user/all');
      setChats(data);
    } catch (err) {
      console.error('Failed to fetch chats:', err.message);
    } finally {
      setLoading(false);
    }
  }, []);

  // Refresh sidebar whenever active chat changes (new message sent)
  useEffect(() => {
    fetchChats();
  }, [activeChatId, fetchChats]);

  const handleDelete = async (e, id) => {
    e.stopPropagation(); // Prevent triggering onSelectChat
    if (!window.confirm('Delete this chat? This cannot be undone.')) return;
    try {
      await api.delete(`/chat/${id}`);
      setChats((prev) => prev.filter((c) => c._id !== id));
      if (activeChatId === id) onNewChat(); // Clear chat if it was active
    } catch (err) {
      console.error('Failed to delete chat:', err.message);
    }
  };

  return (
    <div className="w-64 bg-gray-900 flex flex-col h-full border-r border-gray-800 flex-shrink-0">

      {/* ── Header ── */}
      <div className="p-4 border-b border-gray-800">
        <div className="flex items-center gap-2 mb-1">
          <div className="w-8 h-8 rounded-lg bg-indigo-600 flex items-center
                          justify-center text-white font-bold text-sm">AI</div>
          <h1 className="text-white font-bold text-lg">ChatBot</h1>
        </div>
        <p className="text-gray-500 text-xs truncate">{user?.email}</p>
      </div>

      {/* ── New Chat Button ── */}
      <div className="p-3">
        <button
          onClick={onNewChat}
          className="w-full py-2.5 px-4 bg-indigo-600 hover:bg-indigo-500
                     text-white rounded-xl text-sm font-semibold transition-colors
                     flex items-center justify-center gap-2"
        >
          <span className="text-lg leading-none">+</span>
          New Chat
        </button>
      </div>

      {/* ── Chat Sessions List ── */}
      <div className="flex-1 overflow-y-auto px-2 space-y-0.5">
        {loading && (
          <p className="text-gray-600 text-xs text-center py-4">Loading...</p>
        )}

        {!loading && chats.length === 0 && (
          <p className="text-gray-600 text-xs text-center py-6 px-2">
            No chats yet. Start a conversation!
          </p>
        )}

        {chats.map((chat) => (
          <div
            key={chat._id}
            onClick={() => onSelectChat(chat._id)}
            className={`group flex items-center justify-between p-3 rounded-xl
                        cursor-pointer text-sm transition-colors
                        ${activeChatId === chat._id
                          ? 'bg-indigo-700 text-white'
                          : 'text-gray-400 hover:bg-gray-800 hover:text-gray-200'
                        }`}
          >
            {/* Chat icon + title */}
            <div className="flex items-center gap-2 min-w-0">
              <span className="text-base flex-shrink-0">💬</span>
              <span className="truncate">{chat.title || 'Untitled Chat'}</span>
            </div>

            {/* Delete button - visible on hover */}
            <button
              onClick={(e) => handleDelete(e, chat._id)}
              className="flex-shrink-0 ml-1 text-gray-600 hover:text-red-400
                         opacity-0 group-hover:opacity-100 transition-all
                         w-5 h-5 flex items-center justify-center rounded"
              title="Delete chat"
            >
              ✕
            </button>
          </div>
        ))}
      </div>

      {/* ── User Info + Logout ── */}
      <div className="p-3 border-t border-gray-800">
        <div className="flex items-center gap-2 mb-2 px-1">
          <div className="w-7 h-7 rounded-full bg-indigo-800 flex items-center
                          justify-center text-white text-xs font-bold flex-shrink-0">
            {user?.name?.[0]?.toUpperCase() || 'U'}
          </div>
          <span className="text-gray-400 text-sm truncate">{user?.name}</span>
        </div>
        <button
          onClick={logout}
          className="w-full py-2 px-3 bg-gray-800 hover:bg-red-900/40
                     text-gray-400 hover:text-red-400 rounded-xl text-sm
                     transition-colors"
        >
          Sign Out
        </button>
      </div>
    </div>
  );
}

// ============================================================
// components/ChatInput.jsx - Message Input Bar
// ============================================================

export default function ChatInput({ value, onChange, onSend, loading }) {

  const handleKeyDown = (e) => {
    // Send on Enter (without Shift for new line)
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      onSend();
    }
  };

  return (
    <div className="p-4 bg-gray-900 border-t border-gray-800">
      <div className="flex items-end gap-3 max-w-4xl mx-auto">

        {/* Text Area */}
        <textarea
          rows={1}
          value={value}
          onChange={(e) => onChange(e.target.value)}
          onKeyDown={handleKeyDown}
          placeholder="Type a message… (Enter to send, Shift+Enter for new line)"
          disabled={loading}
          className="flex-1 bg-gray-800 text-gray-100 placeholder-gray-500
                     px-4 py-3 rounded-xl border border-gray-700
                     focus:outline-none focus:border-indigo-500 focus:ring-1
                     focus:ring-indigo-500 resize-none text-sm leading-relaxed
                     transition-colors disabled:opacity-50
                     max-h-40 overflow-y-auto"
          style={{ minHeight: '48px' }}
        />

        {/* Send Button */}
        <button
          onClick={onSend}
          disabled={loading || !value.trim()}
          className="px-5 py-3 bg-indigo-600 hover:bg-indigo-500
                     text-white rounded-xl font-semibold text-sm
                     transition-colors disabled:opacity-40
                     disabled:cursor-not-allowed flex items-center gap-2
                     flex-shrink-0"
        >
          {loading ? (
            <>
              <span className="w-4 h-4 border-2 border-white border-t-transparent
                               rounded-full animate-spin inline-block" />
              Sending
            </>
          ) : (
            <>
              Send
              <span className="text-base">➤</span>
            </>
          )}
        </button>
      </div>

      <p className="text-center text-gray-700 text-xs mt-2">
        AI can make mistakes. Consider checking important information.
      </p>
    </div>
  );
}

// ============================================================
// components/MessageBubble.jsx - Individual Message Display
// ============================================================

export default function MessageBubble({ role, content }) {
  const isUser = role === 'user';

  return (
    <div className={`flex items-end gap-2 mb-4 ${isUser ? 'flex-row-reverse' : 'flex-row'}`}>

      {/* Avatar */}
      <div
        className={`w-8 h-8 rounded-full flex-shrink-0 flex items-center
                    justify-center text-white text-xs font-bold
                    ${isUser ? 'bg-indigo-600' : 'bg-violet-700'}`}
      >
        {isUser ? 'You' : 'AI'}
      </div>

      {/* Message Bubble */}
      <div
        className={`max-w-[75%] px-4 py-3 rounded-2xl text-sm leading-relaxed
                    whitespace-pre-wrap break-words shadow-sm
                    ${isUser
                      ? 'bg-indigo-600 text-white rounded-br-sm'
                      : 'bg-gray-800 text-gray-100 rounded-bl-sm border border-gray-700'
                    }`}
      >
        {content}
      </div>
    </div>
  );
}

// ── Typing Indicator Component ────────────────────────────────
export function TypingIndicator() {
  return (
    <div className="flex items-end gap-2 mb-4">
      <div className="w-8 h-8 rounded-full bg-violet-700 flex-shrink-0
                      flex items-center justify-center text-white text-xs font-bold">
        AI
      </div>
      <div className="bg-gray-800 border border-gray-700 px-4 py-3
                      rounded-2xl rounded-bl-sm">
        <div className="flex items-center gap-1 h-4">
          <span className="typing-dot" />
          <span className="typing-dot" />
          <span className="typing-dot" />
        </div>
      </div>
    </div>
  );
}

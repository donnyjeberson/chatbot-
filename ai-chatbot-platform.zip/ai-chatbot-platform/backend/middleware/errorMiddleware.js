// ============================================================
// middleware/errorMiddleware.js - Global Error Handler
// ============================================================

export const errorHandler = (err, req, res, next) => {
  // Use response status code if set, otherwise default to 500
  const statusCode = res.statusCode && res.statusCode !== 200
    ? res.statusCode
    : 500;

  console.error(`❌ Error: ${err.message}`);

  res.status(statusCode).json({
    message: err.message || 'Internal Server Error',
    // Only show stack trace in development
    stack: process.env.NODE_ENV === 'production' ? null : err.stack,
  });
};

// ============================================================
// controllers/chatController.js - Chat & Message Logic
// ============================================================
import Chat from '../models/Chat.js';
import Message from '../models/Message.js';
import { getAIResponse } from '../services/openaiService.js';

// ── POST /api/chat/send ───────────────────────────────────────
// Send a message and receive an AI response
export const sendMessage = async (req, res, next) => {
  try {
    const { chatId, content } = req.body;

    if (!content || !content.trim()) {
      return res.status(400).json({ message: 'Message content is required.' });
    }

    let chat;

    if (chatId) {
      // Load existing chat
      chat = await Chat.findById(chatId);
      if (!chat || chat.user.toString() !== req.user._id.toString()) {
        return res.status(404).json({ message: 'Chat session not found.' });
      }
    } else {
      // Create a new chat session - use first 50 chars of message as title
      chat = await Chat.create({
        user:  req.user._id,
        title: content.trim().slice(0, 50),
      });
    }

    // Save the user's message to DB
    await Message.create({ chat: chat._id, role: 'user', content: content.trim() });

    // Retrieve recent conversation history for context (last 20 messages)
    const history = await Message.find({ chat: chat._id })
      .sort({ createdAt: 1 })
      .limit(20)
      .select('role content -_id');

    // Get AI response using full conversation context
    const aiText = await getAIResponse(history);

    // Save AI response to DB
    const aiMessage = await Message.create({
      chat:    chat._id,
      role:    'assistant',
      content: aiText,
    });

    // Update chat's updatedAt timestamp
    await Chat.findByIdAndUpdate(chat._id, { updatedAt: new Date() });

    res.status(200).json({
      chat,
      userMessage: { role: 'user', content: content.trim() },
      aiMessage,
    });
  } catch (err) {
    next(err);
  }
};

// ── GET /api/chat/user/all ────────────────────────────────────
// Get all chat sessions for the logged-in user
export const getUserChats = async (req, res, next) => {
  try {
    const chats = await Chat.find({ user: req.user._id })
      .sort({ updatedAt: -1 }); // Most recent first

    res.json(chats);
  } catch (err) {
    next(err);
  }
};

// ── GET /api/chat/:id ─────────────────────────────────────────
// Get all messages for a specific chat session
export const getChatMessages = async (req, res, next) => {
  try {
    const chat = await Chat.findById(req.params.id);

    // Verify chat exists and belongs to the requesting user
    if (!chat || chat.user.toString() !== req.user._id.toString()) {
      return res.status(404).json({ message: 'Chat session not found.' });
    }

    const messages = await Message.find({ chat: chat._id })
      .sort({ createdAt: 1 }); // Oldest first for display

    res.json({ chat, messages });
  } catch (err) {
    next(err);
  }
};

// ── DELETE /api/chat/:id ──────────────────────────────────────
// Delete a chat session and all its messages
export const deleteChat = async (req, res, next) => {
  try {
    const chat = await Chat.findById(req.params.id);

    if (!chat || chat.user.toString() !== req.user._id.toString()) {
      return res.status(404).json({ message: 'Chat session not found.' });
    }

    // Delete all messages in this chat first
    await Message.deleteMany({ chat: chat._id });

    // Delete the chat session itself
    await chat.deleteOne();

    res.json({ message: 'Chat deleted successfully.' });
  } catch (err) {
    next(err);
  }
};

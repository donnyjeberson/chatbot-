// ============================================================
// routes/authRoutes.js - Authentication Routes
// ============================================================
import express from 'express';
import { register, login, getMe } from '../controllers/authController.js';
import { protect } from '../middleware/authMiddleware.js';

const router = express.Router();

router.post('/register', register);       // Public
router.post('/login',    login);          // Public
router.get('/me',        protect, getMe); // Protected

export default router;

// ============================================================
// routes/chatRoutes.js - Chat Routes (all protected)
// ============================================================
import express from 'express';
import { protect } from '../middleware/authMiddleware.js';
import {
  sendMessage,
  getUserChats,
  getChatMessages,
  deleteChat,
} from '../controllers/chatController.js';

const router = express.Router();

// Apply JWT protection to all chat routes
router.use(protect);

router.post('/send',    sendMessage);      // POST   /api/chat/send
router.get('/user/all', getUserChats);     // GET    /api/chat/user/all
router.get('/:id',      getChatMessages);  // GET    /api/chat/:id
router.delete('/:id',   deleteChat);       // DELETE /api/chat/:id

export default router;

// ============================================================
// services/openaiService.js - OpenAI API Wrapper
// ============================================================
import OpenAI from 'openai';

// Initialize OpenAI client with API key from environment
const openai = new OpenAI({
  apiKey: process.env.OPENAI_API_KEY,
});

/**
 * Get a context-aware AI response from OpenAI.
 * @param {Array} messages - Array of { role: 'user'|'assistant', content: string }
 * @returns {string} - The AI's reply text
 */
export const getAIResponse = async (messages) => {
  try {
    const completion = await openai.chat.completions.create({
      model: 'gpt-4o-mini',          // Cost-effective, fast model
      messages: [
        {
          role: 'system',
          content:
            'You are a helpful, knowledgeable, and concise AI assistant. ' +
            'Provide clear, accurate, and well-structured responses. ' +
            'Be friendly but professional.',
        },
        ...messages,
      ],
      max_tokens: 1024,
      temperature: 0.7,              // Balanced creativity vs. accuracy
    });

    return completion.choices[0].message.content;
  } catch (err) {
    console.error('OpenAI API error:', err.message);

    // Provide meaningful error messages based on error type
    if (err.status === 401) throw new Error('Invalid OpenAI API key.');
    if (err.status === 429) throw new Error('OpenAI rate limit exceeded. Please try again later.');
    if (err.status === 500) throw new Error('OpenAI server error. Please try again.');

    throw new Error('AI service is currently unavailable. Please try again.');
  }
};

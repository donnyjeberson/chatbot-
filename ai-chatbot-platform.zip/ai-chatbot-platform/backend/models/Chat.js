// ============================================================
// models/Chat.js - Chat Session Schema
// ============================================================
import mongoose from 'mongoose';

const chatSchema = new mongoose.Schema(
  {
    user: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'User',
      required: true,
    },
    title: {
      type: String,
      default: 'New Chat',
      trim: true,
      maxlength: 100,
    },
  },
  { timestamps: true }
);

export default mongoose.model('Chat', chatSchema);
